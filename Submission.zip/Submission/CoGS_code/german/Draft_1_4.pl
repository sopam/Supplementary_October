
#include('Draft_1_3.pl').
#include('C.pl').



%#show lite_direct/2, not lite_direct/2.
alter(0,X,X).
alter(1,X,Y).

serial_alter(mut(Z1,Z2,Z3,Z4,Z5),A,B,C,D,E,A1,B1,C1,D1,E1):- alter(Z1,A,A1), alter(Z2,B,B1), alter(Z3,C,C1), alter(Z4,D,D1), alter(Z5,E,E1).


lite_direct(mut(Z1,Z2,Z3,Z4,Z5),P,A,B,C,D,E, Q,A1,B1,C1,D1,E1,'<-D1'):- 
    alter(Z1,A,A1), 
    alter(Z2,B,B1), 
    alter(Z3,C,C1), 
    alter(Z4,D,D1), 
    alter(Z5,E,E1),
    A \= A1, 
    B = B1, 
    C = C1,
    D = D1,
    E = E1.

lite_direct(mut(Z1,Z2,Z3,Z4,Z5),P,A,B,C,D,E, Q,A1,B1,C1,D1,E1,'<-D2'):- 
    alter(Z1,A,A1), 
    alter(Z2,B,B1), 
    alter(Z3,C,C1), 
    alter(Z4,D,D1), 
    alter(Z5,E,E1),
    A = A1, 
    B \= B1, 
    C = C1,
    D = D1,
    E = E1.

lite_direct(mut(Z1,Z2,Z3,Z4,Z5),P,A,B,C,D,E, Q,A1,B1,C1,D1,E1,'<-D3'):- 
    alter(Z1,A,A1), 
    alter(Z2,B,B1), 
    alter(Z3,C,C1), 
    alter(Z4,D,D1), 
    alter(Z5,E,E1),
    A = A1, 
    B = B1, 
    C \= C1,
    D = D1,
    E = E1.

lite_direct(mut(Z1,Z2,Z3,Z4,Z5),P,A,B,C,D,E, Q,A1,B1,C1,D1,E1,'<-D4'):- 
    alter(Z1,A,A1), 
    alter(Z2,B,B1), 
    alter(Z3,C,C1), 
    alter(Z4,D,D1), 
    alter(Z5,E,E1),
    A = A1, 
    B = B1, 
    C = C1,
    D \= D1,
    E = E1.


lite_direct(mut(Z1,Z2,Z3,Z4,Z5),P,A,B,C,D,E, Q,A1,B1,C1,D1,E1,'<-D5'):- 
    alter(Z1,A,A1), 
    alter(Z2,B,B1), 
    alter(Z3,C,C1), 
    alter(Z4,D,D1), 
    alter(Z5,E,E1),

    A = A1, 
    B = B1, 
    C = C1,
    D = D1,
    E \= E1.




lite_causal(mut(Z1,Z2,Z3,Z4,Z5),P,A,B,C,D,E, Q,A,B,C,D1,E,'<-C:'):- constraint(D1,G).






lite_intervene(mut(Z1,Z2,Z3,Z4,Z5),P,A,B,C,D,E,Q,A1,B1,C1,D1,E1,Symbol):- 
   lite_direct(mut(Z1,Z2,Z3,Z4,Z5),P,A,B,C,D,E,Q,A1,B1,C1,D1,E1,Symbol).

lite_intervene(mut(Z1,Z2,Z3,Z4,Z5),P,A,B,C,D,E,Q,A1,B1,C1,D1,E1,Symbol):- 
   lite_causal(mut(Z1,Z2,Z3,Z4,Z5),P,A,B,C,D,E,Q,A1,B1,C1,D1,E1,Symbol).








% Show intervene
intervene(Z1,Z2,Z3,Z4,Z5,P,A,B,C,D,E, Q,A1,B1,C1,D1,E1,Symbol):- Q#=P+1,                                
                                checking_account_status(P,A), 
                                checking_account_status(Q,A1), 

                                savings_account_or_bonds(P,B),
                                savings_account_or_bonds(Q,B1),

                                duration_months(P,C),
                                duration_months(Q,C1),

                                present_employment_since(P,D),
                                present_employment_since(Q,D1),

                                job(P,E),
                                job(Q,E1),

                                lite_intervene(mut(Z1,Z2,Z3,Z4,Z5),P,A,B,C,D,E, Q,A1,B1,C1,D1,E1,Symbol).


