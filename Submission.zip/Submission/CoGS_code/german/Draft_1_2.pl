
   
 % IMPORTANT
% The queries for f(domain(X,Y) dont seem to run if we have specifified 2 or more objects (in terms of the properties). Dunno Why

 #include('Draft_1_1.pl').


% Domain: 

    % checking_account_status: {'no_checking_account', -'no_checking_account'}
        f_domain(checking_account_status, '>=200').
        f_domain(checking_account_status, 'no_checking_account').
        
        

        f_domain(checking_account_status, '<0').% Scalability Test
        
        
        %f_domain(checking_account_status, '>=0_and_<200').


    % savings_account_or_bonds: {'all_dues_atbank_cleared', -'all_dues_atbank_cleared'}
        f_domain(savings_account_or_bonds, 'unknown_or_no_savings_account').
        f_domain(savings_account_or_bonds, '500 <= ... < 1000 DM').
        f_domain(savings_account_or_bonds, '< 0 DM'). % Scalability Test


    % duration_months: [4,72]
        f_domain(duration_months, X):- X #>= 4, X #=< 72.








% Properties:
    
    % checking_account_status
           %#show lite_checking_account_status/2, not lite_checking_account_status/2.
        %   #show checking_account_status/2.
        % Produces a binding for every timestamp so we remove the domain of time declaration

        not_lite_checking_account_status(X,Y):- f_domain(checking_account_status,Z) , lite_checking_account_status(X, Z), Z\=Y.
        lite_checking_account_status(X,Y):- not not_lite_checking_account_status(X,Y).
        checking_account_status(X,Y):-f_domain(checking_account_status,Y) ,lite_checking_account_status(X,Y).
        %?- checking_account_status(1,Y).
        %?- f_domain(X,Y).


   % savings_account_or_bonds
           %#show lite_savings_account_or_bonds/2, not lite_savings_account_or_bonds/2.
        %   #show savings_account_or_bonds/2.
        % Produces a binding for every timestamp so we remove the domain of time declaration

        not_lite_savings_account_or_bonds(X,Y):- f_domain(savings_account_or_bonds,Z) , lite_savings_account_or_bonds(X, Z), Z\=Y.
        lite_savings_account_or_bonds(X,Y):- not not_lite_savings_account_or_bonds(X,Y).
        savings_account_or_bonds(X,Y):-f_domain(savings_account_or_bonds,Y) ,lite_savings_account_or_bonds(X,Y).
        %?- savings_account_or_bonds(1,Y).



    % duration_months
           %#show lite_duration_months/2, not lite_duration_months/2.
        %   #show duration_months/2.
    
        %#show lite_duration_months/2, not lite_duration_months/2.
        lite_duration_months(X,Y).
        duration_months(X,Y):-f_domain(duration_months,Y), lite_duration_months(X,Y).
        %?- duration_months(1,Y).
        


