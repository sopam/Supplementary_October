#include('Draft_1_4.pl').

% Decision rule to classify if a person makes has a good credit risk
% lite_good_credit checks if the given input is a counterfactual when applied in conjunction with constraint(F,G)
% lite_good_credit^constraint is the implementation equivalent to is_counterfactual i.e. Algorithm 2.


    lite_bad_credit(A,B,C):- A \= 'no_checking_account', B \= 'unknown_or_no_savings_account', C #> 42.0.





% Good credit instances
    %good_credit(T1, A,B,C,D,E):-legal(T1,A,B,C,D,E), lite_good_credit(A,B,C,D,E).
    %is_counterfactual(T1, A,B,C,D,E,F,G):-legal(T1,A,B,C,D,E,F,G), not lite_good_credit(A,B,C,D,E).

is_counterfactual(T1, A,B,C,D,E):-legal(T1,A,B,C,D,E), constraint(D,E), not lite_good_credit(A,B,C).

% ?-is_counterfactual(1, A,B,C,D,E,F,G).



% Intervention
    
#show intervention/3.
    get_path(_,_,_,_,_,T1,A,B,C,D,E,T1,A,B,C,D,E,Opt,Opt):-legal(T1,A,B,C,D,E), constraint(D,E), not lite_bad_credit(A,B,C).
    
    get_path(Z1,Z2,Z3,Z4,Z5,T1,A,B,C,D,E,TN,A1,B1,C1,D1,E1,Acc,Opt):- 
        %geq(C,C2),geq(F,F2)
        intervene(Z1,Z2,Z3,Z4,Z5,T1,A,B,C,D,E,T2,A2,B2,C2,D2,E2,Symbol)
        , anti_member([A2,B2,C2,D2,E2],Acc) 
        , legal(T1,A,B,C,D,E)
        , lite_bad_credit(A,B,C)
        , get_path(Z1,Z2,Z3,Z4,Z5,T2,A2,B2,C2,D2,E2,TN,A1,B1,C1,D1,E1,[state(time(T2),[A2,B2,C2,D2,E2]),Symbol|Acc], Opt).




% Check if a person P1 has good credit (undesired outcome)
?- T1 #= 1, A ='>=200', B = 'no credits taken/ all credits paid back duly',
     C = 'real estate', D = 7, E = 500, F =  'unemployed', G = 'unemployed/unskilled-non-resident',
    legal(1,A,B,C,D,E,F,G), constraint(F,G), lite_good_credit(A,B,C,D,E).


% Finding path to goal state
  % works
  ?-  T1 #= 1, A ='>=200', B = 'no credits taken/ all credits paid back duly',
       C = 'car or other', D = 7, E = 1500, F =  'unemployed', G = 'unemployed/unskilled-non-resident', %legal(1, A,B,C,D,E,F,G).
       is_counterfactual(1, A1,B1,C1,D1,E1,F1,G1), get_path(1,1,1,1,1,1,1,T1,A,B,C,D,E,F,G,TN,A1,B1,C1,D1,E1,F1,G1,[state(time(T1),[A,B,C,D,E,F,G])],Opt).


?-  T1 #= 1, A ='>=200', B = 'no credits taken/ all credits paid back duly',
    C = 'car or other', D = 7, E = 1500, F =  'unemployed', G = 'unemployed/unskilled-non-resident', 
    get_path(1,1,1,1,1,0,0,T1,A,B,C,D,E,F,G,TN,A1,B1,C1,D1,E1,F1,G1,[state(time(T1),[A,B,C,D,E,F,G])],Opt).




% Scalability Test

?-  T1 #= 1, A ='>=200', B = 'no credits taken/ all credits paid back duly',
    C = 'car or other', D = 7, E = 1500, F =  'unemployed', G = 'unemployed/unskilled-non-resident', 
    get_path(0,1,1,1,1,0,0,T1,A,B,C,D,E,F,G,TN,A1,B1,C1,D1,E1,F1,G1,[state(time(T1),[A,B,C,D,E,F,G])],Opt).

% Length Constrained Scalability Test

?-  T1 #= 1, A ='>=200', B = 'no credits taken/ all credits paid back duly',
    C = 'car or other', D = 7, E = 1500, F =  'unemployed', G = 'unemployed/unskilled-non-resident', 
    get_path(0,1,1,1,1,0,0,T1,A,B,C,D,E,F,G,TN,A1,B1,C1,D1,E1,F1,G1,[state(time(T1),[A,B,C,D,E,F,G])],Opt).



% AISTATS Table 2

% get_path(0,1,1,1,1,0,0,T1,...: Here the 0 indicates the corresponding feature will be immutable with 
% respect to direct actions, i.e., Only causal actions can alter the feature
% In this query, A,F and G can only be altered by causal actions.
?-  TN .=<. 4, T1 #= 1, A ='>=200', B = '500 <= ... < 1000 DM', C = 43, D =  'unemployed', E = 'unemployed/unskilled-non-resident', 
    get_path(0,0,1,0,0,T1,A,B,C,D,E,TN,A1,B1,C1,D1,E1,[state(time(T1),[A,B,C,D,E])],Opt).
