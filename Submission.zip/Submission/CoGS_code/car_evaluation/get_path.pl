#include('Draft_1_4.pl').

	
#show rule_1/1, rule_2/1, rule_3/2, rule_4/2, rule_5/2.
rule_1(X):- X = '2'.
rule_2(X):- X = low.
rule_3(X,Y):- X = vhigh, Y = vhigh.
rule_4(X,Y):- X = vhigh, Y = high.
rule_5(X,Y):- X = high, Y = vhigh.

% Decision rule to classify if a is a car is rejected from consideration

    #show lite_reject/4, not lite_reject/4.
	lite_reject(A,_,_,_):- rule_1(A).
	lite_reject(_,_,_,D):- rule_2(D).
	lite_reject(_,B,C,_):- rule_3(B,C).
	lite_reject(_,B,C,_):- rule_4(B,C).
	lite_reject(_,B,C,_):- rule_5(B,C).

  
% get_paths
    get_path(_,_,_,_,T1,A,B,C,D,T1,A,B,C,D,Opt,Opt):-legal(T1,A,B,C,D), not lite_reject(A,B,C,D).
    
    get_path(Z1,Z2,Z3,Z4,T1,A,B,C,D,TN,A1,B1,C1,D1,Acc,Opt):- intervene(Z1,Z2,Z3,Z4,T1,A,B,C,D,T2,A2,B2,C2,D2,Symbol)
        , anti_member([A2,B2,C2,D2],Acc) 
        , legal(T1,A,B,C,D)
        , lite_reject(A,B,C,D)
        , get_path(Z1,Z2,Z3,Z4,T2,A2,B2,C2,D2,TN,A1,B1,C1,D1,[state(time(T2),[A2,B2,C2,D2]),Symbol|Acc], Opt).




% Obtain instances of the original decision
?-legal(1,A,B,C,D), lite_reject(A,B,C,D).


% Obtain instances of the counterfactual decision
?-legal(2,A1,B1,C1,D1), not lite_reject(A1,B1,C1,D1).

% Get path to the counterfactual
?- A = '4', B = low, C = med, D = med, get_path(0,1,1,1,0,A,B,C,D,TN,A1,B1,C1,D1,[state(time(1),[A,B,C,D])],X).






?-A = '4', B = low, C = med, D = med.%, legal(1,A,B,C,D).%,  lite_reject(A,B,C,D).
?-A = '4',B = low, C = med, legal(1,A,B,C,D).
?-A = '4',B = low, C = med, legal(1,A,B,C,D),  lite_reject(A,B,C,D).
?-legal(1,A,B,C,D),  lite_reject(A,B,C,D).

?-A = '4',B = low, C = med, D = med, legal(1,A,B,C,D),  lite_reject(A,B,C,D).



% Get path to the counterfactual
?- A = '4', B = med, C = med, D = low, get_path(1,1,1,1,1,A,B,C,D,TN,A1,B1,C1,D1,[state(time(1),[A,B,C,D])],X).

